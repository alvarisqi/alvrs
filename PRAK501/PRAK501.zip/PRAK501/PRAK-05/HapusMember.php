<?php
require("model.php");

$id_member = $_GET["id_member"];

if(HapusMember($id_member)> 0 ){
    echo "
    <script>
    alert('Data berhasil dihapus');
    document.location.href = 'member.php';
    </script>
    ";
}
else{
    echo "
    <script>
    alert('Data gagal dihapus');
    document.location.href = 'member.php';
    </script>
    ";
}
?>